package main

import "fmt"

func main() {
	var number int
	fmt.Print("Enter the no of people you want to add: ")
	fmt.Scanln(&number)
	var name string
	var age int
	var categoryMap map[string]string
	categoryMap = make(map[string]string)
	for i := 0; i < number; i++ {
		fmt.Print("Enter your name: ")
		fmt.Scanln(&name)
		fmt.Println("Hello ", name, "!")
		fmt.Print("Enter your age: ")
		fmt.Scanln(&age)
		fmt.Println("Age", age, "years")
		if age < 13 {
			categoryMap[name] = "Child"
		} else if age >= 13 && age < 18 {
			categoryMap[name] = "Teenager"
		} else if age >= 18 && age < 60 {
			categoryMap[name] = "Adult"
		} else {
			categoryMap[name] = "Senior Citizen"
		}
	}

	for person := range categoryMap {
		fmt.Println("Person", person, "belong to", categoryMap[person], "category")
	}

}
